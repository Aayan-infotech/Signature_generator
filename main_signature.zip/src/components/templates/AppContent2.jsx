const AppContent2 = () => {
    return (<>

    </>)
}

export default AppContent2